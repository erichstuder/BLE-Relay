#include <stdio.h>
#include "pico/stdlib.h"
#include "pico/stdio_usb.h"
#include <stdlib.h> // malloc() Relayree()
#include "hardware/pio.h"
#include "hardware/clocks.h"
#include "hardware/pwm.h"
#include "ws2812.pio.h"
#define JDQ1 21
#define JDQ2 20
#define JDQ3 19
#define JDQ4 18
#define JDQ5 17
#define JDQ6 16
#define JDQ7 15
#define JDQ8 14
unsigned char Relay1=1,Relay2=1,Relay3=1,Relay4=1,Relay5=1,Relay6=1,Relay7=1,Relay8=1;
static inline void put_pixel(uint32_t pixel_grb) {
    pio_sm_put_blocking(pio0, 0, pixel_grb << 8u);
}

static inline uint32_t urgb_u32(uint8_t r, uint8_t g, uint8_t b) {
    return
            ((uint32_t) (r) << 8) |
            ((uint32_t) (g) << 16) |
            (uint32_t) (b);
}


uint slice_num;
void DEV_SET_PWM(uint8_t Value){
    if(Value<0 || Value >100){
        printf("DEV_SET_PWM Error \r\n");
    }else {
        pwm_set_chan_level(slice_num, PWM_CHAN_A, Value);
    }
           
}

const int PIN_TX = 13;

int main()
{
    stdio_init_all();

    stdio_usb_init();
    
    gpio_init(JDQ1);
    gpio_init(JDQ2);
    gpio_init(JDQ3);
    gpio_init(JDQ4);
    gpio_init(JDQ5);
    gpio_init(JDQ6);
    gpio_init(JDQ7);
    gpio_init(JDQ8);
    
    gpio_set_dir(JDQ1,GPIO_OUT);
    gpio_set_dir(JDQ2,GPIO_OUT);
    gpio_set_dir(JDQ3,GPIO_OUT);
    gpio_set_dir(JDQ4,GPIO_OUT);
    gpio_set_dir(JDQ5,GPIO_OUT);
    gpio_set_dir(JDQ6,GPIO_OUT);
    gpio_set_dir(JDQ7,GPIO_OUT);
    gpio_set_dir(JDQ8,GPIO_OUT);
    PIO pio = pio0;
    int sm = 0;
    uint offset = pio_add_program(pio, &ws2812_program);

    ws2812_program_init(pio, sm, offset, PIN_TX, 800000, true);

    gpio_set_function(6, GPIO_FUNC_PWM);
    slice_num = pwm_gpio_to_slice_num(6);
    pwm_set_wrap(slice_num, 500);
    pwm_set_chan_level(slice_num, PWM_CHAN_A, 1);
    pwm_set_clkdiv(slice_num,50);
    pwm_set_enabled(slice_num, true);
    char *buf;
    int i=1,count=-1;
    put_pixel(urgb_u32(0,0,0));//RGB
    //DEV_SET_PWM(80); //buzzer
    while(1){
        i=stdio_usb_in_chars(buf,10);
        switch(i)
        {
            case 1:{gpio_put(JDQ1,Relay1);
                    if(Relay1==1)
                    {
		                put_pixel(urgb_u32(255,0,0));
                        DEV_SET_PWM(80); //buzzer
                        DEV_Delay_ms(100);
                        DEV_SET_PWM(0);
                        printf("****Relay 1 on*****\r\n\n");
                    }
                    else if(Relay1==0)
                        printf("****Relay 1 off*****\r\n\n");
                    Relay1=!Relay1;
                    break;}
            case 2:{gpio_put(JDQ2,Relay2);
		    if(Relay2==1)
			    {
                    put_pixel(urgb_u32(0,255,0));
                    DEV_SET_PWM(80); //buzzer
                    DEV_Delay_ms(100);
                    DEV_SET_PWM(0);
                    printf("****Relay 2 on*****\r\n\n");
                }
                    else if(Relay2==0)
                            printf("****Relay 2 off****\r\n\n");

                    Relay2=!Relay2;	
                    break;}
            case 3:{gpio_put(JDQ3,Relay3);
		    if(Relay3==1)
			{
                put_pixel(urgb_u32(0,0,255));
                DEV_SET_PWM(80); //buzzer
                DEV_Delay_ms(100);
                DEV_SET_PWM(0);
                printf("****Relay 3 on*****\r\n\n");
            }
                    else if(Relay3==0)
                        printf("****Relay 3 off****\r\n\n");
                    Relay3=!Relay3;
                    break;}
            case 4:{gpio_put(JDQ4,Relay4);
		    if(Relay4==1)
            {
			    put_pixel(urgb_u32(255,255,0));
                DEV_SET_PWM(80); //buzzer
                DEV_Delay_ms(100);
                DEV_SET_PWM(0);
                printf("****Relay 4 on*****\r\n\n");
                }
            else if(Relay4==0)
                printf("****Relay 4 off****\r\n\n");
                Relay4=!Relay4;	
                break;}
            case 5:{gpio_put(JDQ5,Relay5);
		    if(Relay5==1)
			{
                put_pixel(urgb_u32(255,0,255));
                DEV_SET_PWM(80); //buzzer
                DEV_Delay_ms(100);
                DEV_SET_PWM(0);
                printf("****Relay 5 on*****\r\n\n");
            }
                else if(Relay5==0)
                        printf("****Relay 5 off****\r\n\n");
                    Relay5=!Relay5;	
                    break;}
            case 6:{gpio_put(JDQ6,Relay6);
		    if(Relay6==1)
			{
                printf("****Relay 6 on*****\r\n\n");
                DEV_SET_PWM(80); //buzzer
                DEV_Delay_ms(100);
                DEV_SET_PWM(0);
                put_pixel(urgb_u32(0,255,255));
            }
                    else if(Relay6==0)
                        printf("****Relay 6 off****\r\n\n");
                    Relay6=!Relay6;	
                    break;}
            case 7:{gpio_put(JDQ7,Relay7);
		    if(Relay7==1)
            {
			    put_pixel(urgb_u32(127,127,255));
                DEV_SET_PWM(80); //buzzer
                DEV_Delay_ms(100);
                DEV_SET_PWM(0);
                printf("****Relay 7 on*****\r\n\n");
            }
                    else if(Relay7==0)
                    printf("****Relay 7 off****\r\n\n");
                    Relay7=!Relay7;	
                    break;}
            case 8:{gpio_put(JDQ8,Relay8);
		    if(Relay8==1)
            {
                put_pixel(urgb_u32(255,255,255));
                DEV_SET_PWM(80); //buzzer
                DEV_Delay_ms(100);
                DEV_SET_PWM(0);			    
                printf("****Relay 8 on*****\r\n\n");
            }
                    else if(Relay8==0)
                    printf("****Relay 8 off****\r\n\n");
                    Relay8=!Relay8;	
                    break;}
            case 9:{gpio_put(JDQ8,0);
                    gpio_put(JDQ7,0);
                    gpio_put(JDQ6,0);
                    gpio_put(JDQ5,0);
                    gpio_put(JDQ4,0);
                    gpio_put(JDQ3,0);
                    gpio_put(JDQ2,0);
                    gpio_put(JDQ1,0);
		            printf("***Relay ALL off***\r\n\n");
                    Relay1=Relay2=Relay3=Relay4=Relay5=Relay6=Relay7=Relay8=1;
                    put_pixel(urgb_u32(0,0,0));	
                    break;}
            case 10:{gpio_put(JDQ8,1);
                    gpio_put(JDQ7,1);
                    gpio_put(JDQ6,1);
                    gpio_put(JDQ5,1);
                    gpio_put(JDQ4,1);
                    gpio_put(JDQ3,1);
                    gpio_put(JDQ2,1);
                    gpio_put(JDQ1,1);                   
		            printf("***Relay ALL on****\r\n\n");
                    Relay1=Relay2=Relay3=Relay4=Relay5=Relay6=Relay7=Relay8=0;
                    put_pixel(urgb_u32(255,255,255));
                    DEV_SET_PWM(80); //buzzer
                    DEV_Delay_ms(100);
                    DEV_SET_PWM(0);	
                    break;}
            default: break;  
		}	       
        if(count==0)
           {
                count=1;
                printf("****System stability****\r\n\r\n"); 
           }
        else if(count==-1)
              {  
                printf("***System restart...****\r\n\r\n");
                sleep_ms(2000);
                count++;
              }
    }

    return 0;
}
