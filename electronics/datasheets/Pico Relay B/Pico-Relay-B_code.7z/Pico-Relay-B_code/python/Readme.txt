20210701：Add Pico-Relay-B example


